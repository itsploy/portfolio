<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>bootstrap</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.min.js" integrity="sha384-7VPbUDkoPSGFnVtYi0QogXtr74QeVeeIs99Qfg5YCF+TidwNdjvaKZX19NZ/e6oz" crossorigin="anonymous"></script>
    <link rel="stylesheet" type="text/css" href="styles.css">
    <link href="https://fonts.googleapis.com/css2?family=Prompt&display=swap" rel="stylesheet">

  
</head>
<body> 
  
  <!--การสร้างเมนู-->
  <header class="p-3 text-bg-white text-dark">

  <style>
    div{
      background-color: #ffffff;
      background-image: url('https://cdn.pixabay.com/photo/2018/01/11/21/27/laptop-3076957_1280.jpg');
      background-position: center;
      background-size: cover;
      background-repeat: no-repeat;
      text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.8);
      font-family: 'Prompt', monospace;
        
    }
        
  </style>

<div class="cover-container d-flex w-100 h-100 p-3 mx-auto flex-column">
  <header class="mb-auto">
    <div>
      
      <nav class="nav nav-masthead justify-content-center float-md-end">
        <a class="text-decoration-underline nav-link px-2 link-dark fs-5" aria-current="page" href="http://[::1]/CI/index.php/bootstrap/">หน้าแรก</a>
        <a class="text-decoration-underline nav-link px-2 link-dark fs-5" href="http://[::1]/CI/index.php/about/">เกี่ยวกับฉัน</a>
        <a class="text-decoration-underline nav-link px-2 link-dark fs-5" href="http://[::1]/CI/index.php/ac/">ผลงานทางวิชาการ</a>
        <a class="text-decoration-underline nav-link px-2 link-dark fs-5" href="http://[::1]/CI/index.php/acti/">กิจกรรม</a>
        <a class="text-decoration-underline nav-link px-2 link-dark fs-5" href="http://[::1]/CI/index.php/cont/">ติดต่อข้อมูล</a>
      </nav>
    </div>
        
    <main class="px-100">
    <br><br><br><br><br><br><br><br><br><br><br><br>
    
    <h1> <p class="text-center">"ยินดีต้อนรับเข้าสู่หน้าเพจของฉัน"</p> </h1>

    </main>
  </header>
        
  </header>
</body>
</html>
     

      