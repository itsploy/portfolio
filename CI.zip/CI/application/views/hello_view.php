<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Welcome to HELLO WORLD</title>
</head>
<body>
<div id="container">
	<h1>HELLO WORLD</h1>
	
	<h1>HTML Heplper</h1>
	aaaa<br>bbbb
	<br>
	cccc 
	<?php echo br(3);?>
	dddd

	<p>Heaging</p>
	<h1>H1</h1>
	<h2>H1</h2>
	<h6>H1</h6>

	<?php 
		echo heading("Boontharika",1);
		echo heading("Boontharika",2);
		echo heading("Boontharika",3);
		echo heading("Boontharika",4);
		echo heading("Boontharika",5);
		
	?>

	<hr>
	<p>OL</p>
	<?php
		$list=array('a','b','c','d');
		echo ol($list);
		echo '<hr>';
		echo ul($list);
	?>

</body>
</html>
