<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Page index2</title>
</head>

<body>
<div id="container">
	<h1>Index2</h1>
	
</body>
</html>
