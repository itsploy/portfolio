<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>About</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.min.js" integrity="sha384-7VPbUDkoPSGFnVtYi0QogXtr74QeVeeIs99Qfg5YCF+TidwNdjvaKZX19NZ/e6oz" crossorigin="anonymous"></script>
    <link rel="stylesheet" type="text/css" href="styles.css">
    <link href="https://fonts.googleapis.com/css2?family=Prompt&display=swap" rel="stylesheet">
</head>

<body>
<!--การสร้างเมนู-->


<style>
  div{
    background-color: #e9edf1;
    background-image: url('https://images.pexels.com/photos/1202413/pexels-photo-1202413.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940');
    background-position: center;
    background-size: cover;
    background-repeat: no-repeat;
    text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.8);
    font-family: 'Prompt', monospace;      
  }
  h1{
    color: #ffffff;
    text-align: center; 
    text-decoration: underline;
    text-transform: capitalize;
  }
  div{
    
  }

      
</style>
        
<main>
<div class="cover-container d-flex w-100 h-100 p-3 mx-auto flex-column">
  <header class="mb-auto">
  <div>  
      <nav class="nav nav-masthead justify-content-center float-md-end">
        <a class="text-decoration-underline nav-link px-2 link-dark fs-5" aria-current="page" href="http://[::1]/CI/index.php/bootstrap/">หน้าแรก</a>
        <a class="text-decoration-underline nav-link px-2 link-dark fs-5" href="http://[::1]/CI/index.php/about/">เกี่ยวกับฉัน</a>
        <a class="text-decoration-underline nav-link px-2 link-dark fs-5" href="http://[::1]/CI/index.php/ac/">ผลงานทางวิชาการ</a>
        <a class="text-decoration-underline nav-link px-2 link-dark fs-5" href="http://[::1]/CI/index.php/acti/">กิจกรรม</a>
        <a class="text-decoration-underline nav-link px-2 link-dark fs-5" href="http://[::1]/CI/index.php/cont/">ติดต่อข้อมูล</a>
      </nav>
    </div>
        <br><br>
            <h1 class="display-1ุ5 fw-normal text-dark">เกี่ยวกับฉัน</h1>
<br>
<center><img src="https://scontent.fphs2-1.fna.fbcdn.net/v/t1.6435-9/125210526_1348142255360907_1987223684111876232_n.jpg?_nc_cat=100&ccb=1-7&_nc_sid=8bfeb9&_nc_ohc=dcd8w4QlxWkAX9O2czg&tn=BB91tgiFflyyvWq1&_nc_ht=scontent.fphs2-1.fna&oh=00_AT9Kx6VhpNwm0rQU4GuWqZGeasIc87siPuDsX0SSCBgMHg&oe=63604D70" alt="" width="190px"> </center>
<br>
<br>
            <p class="text-center fw-normal text-dark fs-6">ชื่อจริง บุณฑริกา เชื้อชุ่ม </p>  
            <p class="text-center fw-normal text-dark fs-6">ชื่อเล่น พลอย อายุ 20 ปี</p>
            <p class="text-center fw-normal text-dark fs-6">เกิดวันที่ 8 มกราคม 2545</p>     
            <p class="text-center fw-normal text-dark fs-6">ที่อยู่ 261/10 ตำบลแม่แวน อำเภอพร้าว จังหวัดเชียงใหม่  รหัสไปรษณีย์ 50190</p>
            <p class="text-center fw-normal text-dark fs-6">กำลังศึกษาอยู่ที่ มหาวิทยาลัยเทคโนโลยีราชมงคลล้านนา ตาก</p>
            <p class="text-center fw-normal text-dark fs-5">คติประจำใจ ทำในสิ่งที่ตัวเองชอบ แล้วชีวิตจะมีความสุข</p> 
              
            <br>
    </main>
</body>
</html>