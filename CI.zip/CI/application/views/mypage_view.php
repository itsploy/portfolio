<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>my page</title>
</head>

<body>
<div id="container">
	<h1>MY PAGE VIEW</h1>
    <h2 id="fr">TEST CSS</h2>
    
  <nav class="navbar navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand">Navbar</a>
    <form class="d-flex" role="search">
      <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-success" type="submit">Search</button>
    </form>
  </div>
</nav>

</nav>
    <p class="text-primary"> สวัสดี</p>
    <p class="text-secondary">วันจันทร์</p>
    <p class="text-success">12 ก.ย.2565</p>
    <p class="text-danger"> Have a nice day!!</p>
<br>
    <button type="button" class="btn btn-primary">น้ำเงิน</button>
    <button type="button" class="btn btn-warning">เหลือง</button>
    <button type="button" class="btn btn-danger">แดง</button>
<br>

    <a href="<?php echo site_url('Hello');?>">Link to Hello</a>
    <br>
    <a href="<?php echo site_url('Welcome');?>">Link to welcome</a>
    <br>
    <img src="<?php echo base_url('img');?>/me.jpg" alt="" width="200px">

</body>
</html>
