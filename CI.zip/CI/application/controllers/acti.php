<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class acti extends CI_Controller {
	public function index()
	{
        $this->load->view('mycss');
		$this->load->view('acti_view');
	}
	public function index2()
	{
		$this->load->view('acti_view');
	}
}