<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class About extends CI_Controller {
	public function index()
	{
        $this->load->view('mycss');
		$this->load->view('about_view');
	}
	public function index2()
	{
		$this->load->view('about_view');
	}
}